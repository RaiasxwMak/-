import React, { useState } from "react";
import { AIGenerator } from "./components/AIGenerator";
import { PresentationEditor } from "./components/PresentationEditor";
import { AIService } from "./services/aiService";
import { ExportService } from "./services/exportService";
import type { Presentation, AIGenerationRequest } from "./types/presentation";
import toast, { Toaster } from "react-hot-toast";

function App() {
  const [currentView, setCurrentView] = useState<"generator" | "editor">(
    "generator"
  );
  const [presentation, setPresentation] = useState<Presentation | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);

  const aiService = AIService.getInstance();

  const handleGenerate = async (request: AIGenerationRequest) => {
    setIsGenerating(true);

    try {
      const response = await aiService.generatePresentation(request);

      if (response.success) {
        const newPresentation: Presentation = {
          ...response.presentation,
          id: `presentation-${Date.now()}`,
          createdAt: new Date(),
          updatedAt: new Date(),
        };

        setPresentation(newPresentation);
        setCurrentView("editor");
        toast.success("Презентация успешно создана!");
      } else {
        toast.error(response.error || "Ошибка при создании презентации");
      }
    } catch (error) {
      toast.error("Произошла ошибка при генерации презентации");
      console.error("Generation error:", error);
    } finally {
      setIsGenerating(false);
    }
  };

  const handleUpdatePresentation = (updatedPresentation: Presentation) => {
    setPresentation(updatedPresentation);
  };

  const handleExport = async () => {
    if (!presentation) return;

    try {
      const exportService = ExportService.getInstance();
      await exportService.exportToPDF(presentation);
      toast.success("Презентация успешно экспортирована в PDF!");
    } catch (error) {
      toast.error("Ошибка при экспорте презентации");
      console.error("Export error:", error);
    }
  };

  const handleBackToGenerator = () => {
    setCurrentView("generator");
    setPresentation(null);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Toaster
        position="top-right"
        toastOptions={{
          duration: 4000,
          style: {
            background: "#363636",
            color: "#fff",
          },
        }}
      />

      {currentView === "generator" ? (
        <AIGenerator onGenerate={handleGenerate} isGenerating={isGenerating} />
      ) : presentation ? (
        <PresentationEditor
          presentation={presentation}
          onUpdatePresentation={handleUpdatePresentation}
          onExport={handleExport}
          onBack={handleBackToGenerator}
        />
      ) : null}
    </div>
  );
}

export default App;
