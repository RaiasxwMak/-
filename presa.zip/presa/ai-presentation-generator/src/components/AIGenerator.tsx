import React, { useState } from "react";
import { Button } from "./ui/Button";
import { Input, Textarea } from "./ui/Input";
import type { AIGenerationRequest } from "../types/presentation";

interface AIGeneratorProps {
  onGenerate: (request: AIGenerationRequest) => Promise<void>;
  isGenerating: boolean;
}

export const AIGenerator: React.FC<AIGeneratorProps> = ({
  onGenerate,
  isGenerating,
}) => {
  const [prompt, setPrompt] = useState("");
  const [slideCount, setSlideCount] = useState(5);
  const [tone, setTone] = useState<
    "professional" | "casual" | "academic" | "creative"
  >("professional");
  const [audience, setAudience] = useState("");

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!prompt.trim()) return;

    await onGenerate({
      prompt: prompt.trim(),
      slideCount,
      tone,
      audience: audience.trim() || undefined,
    });
  };

  const toneOptions = [
    { value: "professional", label: "Профессиональный" },
    { value: "casual", label: "Неформальный" },
    { value: "academic", label: "Академический" },
    { value: "creative", label: "Креативный" },
  ];

  return (
    <div className="max-w-4xl mx-auto p-6">
      <div className="text-center mb-8">
        <h1 className="text-4xl font-bold text-gray-900 mb-4">
          AI Генератор Презентаций
        </h1>
        <p className="text-xl text-gray-600">
          Создайте профессиональную презентацию за считанные секунды с помощью
          искусственного интеллекта
        </p>
      </div>

      <div className="bg-white rounded-xl shadow-lg border border-gray-200 p-8">
        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <Textarea
              label="Тема презентации"
              placeholder="Опишите тему вашей презентации. Например: 'Маркетинговая стратегия для запуска нового продукта' или 'Влияние искусственного интеллекта на будущее образования'"
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              rows={4}
              required
              helperText="Чем подробнее вы опишете тему, тем качественнее будет результат"
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Количество слайдов
              </label>
              <select
                value={slideCount}
                onChange={(e) => setSlideCount(Number(e.target.value))}
                className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
              >
                {[3, 5, 7, 10, 15].map((count) => (
                  <option key={count} value={count}>
                    {count} слайдов
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Стиль презентации
              </label>
              <select
                value={tone}
                onChange={(e) =>
                  setTone(
                    e.target.value as
                      | "professional"
                      | "casual"
                      | "academic"
                      | "creative"
                  )
                }
                className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
              >
                {toneOptions.map((option) => (
                  <option key={option.value} value={option.value}>
                    {option.label}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div>
            <Input
              label="Целевая аудитория (опционально)"
              placeholder="Например: студенты, бизнес-руководители, технические специалисты"
              value={audience}
              onChange={(e) => setAudience(e.target.value)}
              helperText="Укажите, для кого предназначена презентация"
            />
          </div>

          <div className="flex justify-center pt-4">
            <Button
              type="submit"
              size="lg"
              loading={isGenerating}
              disabled={!prompt.trim() || isGenerating}
              className="px-8 py-3"
            >
              {isGenerating
                ? "Генерируем презентацию..."
                : "Создать презентацию"}
            </Button>
          </div>
        </form>
      </div>

      <div className="mt-8 grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="text-center p-6">
          <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mx-auto mb-4">
            <svg
              className="w-6 h-6 text-blue-600"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M13 10V3L4 14h7v7l9-11h-7z"
              />
            </svg>
          </div>
          <h3 className="text-lg font-semibold text-gray-900 mb-2">Быстро</h3>
          <p className="text-gray-600">
            Создание презентации за несколько секунд
          </p>
        </div>

        <div className="text-center p-6">
          <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mx-auto mb-4">
            <svg
              className="w-6 h-6 text-green-600"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"
              />
            </svg>
          </div>
          <h3 className="text-lg font-semibold text-gray-900 mb-2">
            Качественно
          </h3>
          <p className="text-gray-600">Профессиональный контент и дизайн</p>
        </div>

        <div className="text-center p-6">
          <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center mx-auto mb-4">
            <svg
              className="w-6 h-6 text-purple-600"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M11 4a2 2 0 114 0v1a1 1 0 001 1h3a1 1 0 011 1v3a1 1 0 01-1 1h-1a2 2 0 100 4h1a1 1 0 011 1v3a1 1 0 01-1 1h-3a1 1 0 01-1-1v-1a2 2 0 10-4 0v1a1 1 0 01-1 1H7a1 1 0 01-1-1v-3a1 1 0 011-1h1a2 2 0 100-4H7a1 1 0 01-1-1V7a1 1 0 011-1h3a1 1 0 001-1V4z"
              />
            </svg>
          </div>
          <h3 className="text-lg font-semibold text-gray-900 mb-2">
            Настраиваемо
          </h3>
          <p className="text-gray-600">Легко редактировать и адаптировать</p>
        </div>
      </div>
    </div>
  );
};
