import React, { useState } from "react";
import { SlideViewer } from "./presentation/SlideViewer";
import { SlideNavigation } from "./presentation/SlideNavigation";
import { Button } from "./ui/Button";
import type { Presentation, Slide } from "../types/presentation";

interface PresentationEditorProps {
  presentation: Presentation;
  onUpdatePresentation: (presentation: Presentation) => void;
  onExport?: () => void;
  onBack?: () => void;
}

export const PresentationEditor: React.FC<PresentationEditorProps> = ({
  presentation,
  onUpdatePresentation,
  onExport,
  onBack,
}) => {
  const [currentSlideIndex, setCurrentSlideIndex] = useState(0);
  const [isEditing, setIsEditing] = useState(false);

  const currentSlide = presentation.slides[currentSlideIndex];

  const handleSlideUpdate = (updatedSlide: Slide) => {
    const updatedSlides = [...presentation.slides];
    updatedSlides[currentSlideIndex] = updatedSlide;

    onUpdatePresentation({
      ...presentation,
      slides: updatedSlides,
      updatedAt: new Date(),
    });
  };

  const handleAddSlide = () => {
    const newSlide: Slide = {
      id: `slide-${Date.now()}`,
      title: "Новый слайд",
      content: "Содержимое слайда",
      layout: "content",
    };

    const updatedSlides = [...presentation.slides, newSlide];
    onUpdatePresentation({
      ...presentation,
      slides: updatedSlides,
      updatedAt: new Date(),
    });

    setCurrentSlideIndex(updatedSlides.length - 1);
  };

  const handleDeleteSlide = (index: number) => {
    if (presentation.slides.length <= 1) return;

    const updatedSlides = presentation.slides.filter((_, i) => i !== index);
    onUpdatePresentation({
      ...presentation,
      slides: updatedSlides,
      updatedAt: new Date(),
    });

    if (currentSlideIndex >= updatedSlides.length) {
      setCurrentSlideIndex(updatedSlides.length - 1);
    }
  };

  const handleKeyDown = (e: KeyboardEvent) => {
    if (e.key === "ArrowLeft" && currentSlideIndex > 0) {
      setCurrentSlideIndex(currentSlideIndex - 1);
    } else if (
      e.key === "ArrowRight" &&
      currentSlideIndex < presentation.slides.length - 1
    ) {
      setCurrentSlideIndex(currentSlideIndex + 1);
    }
  };

  React.useEffect(() => {
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [currentSlideIndex, presentation.slides.length]);

  return (
    <div className="flex h-screen bg-gray-100">
      <SlideNavigation
        slides={presentation.slides}
        currentSlideIndex={currentSlideIndex}
        onSlideSelect={setCurrentSlideIndex}
        onAddSlide={handleAddSlide}
        onDeleteSlide={handleDeleteSlide}
      />

      <div className="flex-1 flex flex-col">
        <header className="bg-white border-b border-gray-200 px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-4">
            {onBack && (
              <Button variant="outline" onClick={onBack} size="sm">
                ← Назад
              </Button>
            )}
            <div>
              <h1 className="text-xl font-semibold text-gray-900">
                {presentation.title}
              </h1>
              <p className="text-sm text-gray-500">
                Слайд {currentSlideIndex + 1} из {presentation.slides.length}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <Button
              variant="outline"
              onClick={() => setIsEditing(!isEditing)}
              size="sm"
            >
              {isEditing ? "Просмотр" : "Редактирование"}
            </Button>
            {onExport && (
              <Button onClick={onExport} size="sm">
                Экспорт PDF
              </Button>
            )}
          </div>
        </header>

        <main className="flex-1 p-6">
          <div className="max-w-4xl mx-auto">
            {isEditing ? (
              <SlideEditor slide={currentSlide} onUpdate={handleSlideUpdate} />
            ) : (
              <div className="relative">
                <SlideViewer slide={currentSlide} />

                <div className="flex justify-between items-center mt-6">
                  <Button
                    variant="outline"
                    onClick={() =>
                      setCurrentSlideIndex(Math.max(0, currentSlideIndex - 1))
                    }
                    disabled={currentSlideIndex === 0}
                  >
                    ← Предыдущий
                  </Button>

                  <span className="text-sm text-gray-500">
                    {currentSlideIndex + 1} / {presentation.slides.length}
                  </span>

                  <Button
                    variant="outline"
                    onClick={() =>
                      setCurrentSlideIndex(
                        Math.min(
                          presentation.slides.length - 1,
                          currentSlideIndex + 1
                        )
                      )
                    }
                    disabled={
                      currentSlideIndex === presentation.slides.length - 1
                    }
                  >
                    Следующий →
                  </Button>
                </div>
              </div>
            )}
          </div>
        </main>
      </div>
    </div>
  );
};

interface SlideEditorProps {
  slide: Slide;
  onUpdate: (slide: Slide) => void;
}

const SlideEditor: React.FC<SlideEditorProps> = ({ slide, onUpdate }) => {
  const [title, setTitle] = useState(slide.title);
  const [content, setContent] = useState(slide.content);
  const [layout, setLayout] = useState(slide.layout);

  const handleSave = () => {
    onUpdate({
      ...slide,
      title,
      content,
      layout,
    });
  };

  const layoutOptions = [
    { value: "title", label: "Титульный слайд" },
    { value: "content", label: "Контент" },
    { value: "bullet-points", label: "Список" },
    { value: "two-column", label: "Две колонки" },
    { value: "image", label: "С изображением" },
  ];

  return (
    <div className="bg-white rounded-lg shadow-lg border border-gray-200 p-6">
      <div className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Заголовок слайда
          </label>
          <input
            type="text"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-blue-500 focus:border-blue-500"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Макет слайда
          </label>
          <select
            value={layout}
            onChange={(e) => setLayout(e.target.value as Slide["layout"])}
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-blue-500 focus:border-blue-500"
          >
            {layoutOptions.map((option) => (
              <option key={option.value} value={option.value}>
                {option.label}
              </option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Содержимое
          </label>
          <textarea
            value={content}
            onChange={(e) => setContent(e.target.value)}
            rows={8}
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-blue-500 focus:border-blue-500"
          />
          {layout === "two-column" && (
            <p className="text-sm text-gray-500 mt-1">
              Разделите содержимое двух колонок с помощью "---"
            </p>
          )}
        </div>

        <div className="flex justify-end">
          <Button onClick={handleSave}>Сохранить изменения</Button>
        </div>
      </div>
    </div>
  );
};
