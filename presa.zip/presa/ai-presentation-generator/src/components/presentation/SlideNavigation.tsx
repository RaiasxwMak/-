import React from "react";
import type { Slide } from "../../types/presentation";

interface SlideThumbnailProps {
  slide: Slide;
  index: number;
  isSelected: boolean;
  onClick: () => void;
}

const SlideThumbnail: React.FC<SlideThumbnailProps> = ({
  slide,
  index,
  isSelected,
  onClick,
}) => {
  return (
    <div
      className={`
        relative cursor-pointer rounded-lg border-2 transition-all duration-200 p-2 bg-white
        ${
          isSelected
            ? "border-blue-500 shadow-md"
            : "border-gray-200 hover:border-gray-300"
        }
      `}
      onClick={onClick}
    >
      <div className="aspect-video bg-gray-50 rounded border overflow-hidden">
        <div className="p-2 text-xs">
          <div className="font-semibold truncate">{slide.title}</div>
          <div className="text-gray-600 line-clamp-2 mt-1">
            {slide.content.substring(0, 50)}...
          </div>
        </div>
      </div>
      <div className="absolute -top-1 -left-1 bg-blue-600 text-white rounded-full w-6 h-6 flex items-center justify-center text-xs font-semibold">
        {index + 1}
      </div>
    </div>
  );
};

interface SlideNavigationProps {
  slides: Slide[];
  currentSlideIndex: number;
  onSlideSelect: (index: number) => void;
  onAddSlide?: () => void;
  onDeleteSlide?: (index: number) => void;
}

export const SlideNavigation: React.FC<SlideNavigationProps> = ({
  slides,
  currentSlideIndex,
  onSlideSelect,
  onAddSlide,
  onDeleteSlide,
}) => {
  return (
    <div className="w-64 bg-gray-50 border-r border-gray-200 flex flex-col">
      <div className="p-4 border-b border-gray-200">
        <h3 className="font-semibold text-gray-800 mb-3">Слайды</h3>
        {onAddSlide && (
          <button
            onClick={onAddSlide}
            className="w-full flex items-center justify-center gap-2 py-2 px-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
          >
            <svg
              className="w-4 h-4"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M12 4v16m8-8H4"
              />
            </svg>
            Добавить слайд
          </button>
        )}
      </div>

      <div className="flex-1 overflow-y-auto p-4 space-y-3">
        {slides.map((slide, index) => (
          <div key={slide.id} className="relative group">
            <SlideThumbnail
              slide={slide}
              index={index}
              isSelected={index === currentSlideIndex}
              onClick={() => onSlideSelect(index)}
            />
            {onDeleteSlide && slides.length > 1 && (
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  onDeleteSlide(index);
                }}
                className="absolute -top-1 -right-1 bg-red-500 text-white rounded-full w-6 h-6 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity hover:bg-red-600"
              >
                <svg
                  className="w-3 h-3"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M6 18L18 6M6 6l12 12"
                  />
                </svg>
              </button>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};
