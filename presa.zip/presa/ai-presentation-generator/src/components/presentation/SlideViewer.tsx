import React from "react";
import type { Slide } from "../../types/presentation";

interface SlideViewerProps {
  slide: Slide;
  isSelected?: boolean;
  onClick?: () => void;
  onEdit?: (slide: Slide) => void;
}

export const SlideViewer: React.FC<SlideViewerProps> = ({
  slide,
  isSelected = false,
  onClick,
  onEdit,
}) => {
  const renderContent = () => {
    switch (slide.layout) {
      case "title":
        return (
          <div className="h-full flex flex-col justify-center items-center text-center">
            <h1 className="text-4xl font-bold text-gray-800 mb-4">
              {slide.title}
            </h1>
            <p className="text-xl text-gray-600">{slide.content}</p>
          </div>
        );

      case "content":
        return (
          <div className="h-full flex flex-col">
            <h2 className="text-3xl font-bold text-gray-800 mb-6">
              {slide.title}
            </h2>
            <div className="flex-1 text-lg text-gray-700 leading-relaxed">
              {slide.content.split("\n").map((line, index) => (
                <p key={index} className="mb-4">
                  {line}
                </p>
              ))}
            </div>
          </div>
        );

      case "bullet-points":
        return (
          <div className="h-full flex flex-col">
            <h2 className="text-3xl font-bold text-gray-800 mb-6">
              {slide.title}
            </h2>
            <ul className="flex-1 space-y-3 text-lg text-gray-700">
              {slide.content
                .split("\n")
                .filter((line) => line.trim())
                .map((point, index) => (
                  <li key={index} className="flex items-start">
                    <span className="w-2 h-2 bg-blue-600 rounded-full mt-3 mr-4 flex-shrink-0"></span>
                    <span>{point.replace(/^[•\-*]\s*/, "")}</span>
                  </li>
                ))}
            </ul>
          </div>
        );

      case "two-column": {
        const [leftContent, rightContent] = slide.content.split("---");
        return (
          <div className="h-full flex flex-col">
            <h2 className="text-3xl font-bold text-gray-800 mb-6">
              {slide.title}
            </h2>
            <div className="flex-1 grid grid-cols-2 gap-8">
              <div className="text-lg text-gray-700">
                {leftContent?.split("\n").map((line, index) => (
                  <p key={index} className="mb-4">
                    {line}
                  </p>
                ))}
              </div>
              <div className="text-lg text-gray-700">
                {rightContent?.split("\n").map((line, index) => (
                  <p key={index} className="mb-4">
                    {line}
                  </p>
                ))}
              </div>
            </div>
          </div>
        );
      }

      default:
        return (
          <div className="h-full flex flex-col justify-center items-center">
            <h2 className="text-2xl font-bold text-gray-800 mb-4">
              {slide.title}
            </h2>
            <p className="text-gray-600">{slide.content}</p>
          </div>
        );
    }
  };

  return (
    <div
      className={`
        bg-white rounded-lg shadow-md border-2 aspect-video p-8 cursor-pointer transition-all duration-200
        ${
          isSelected
            ? "border-blue-500 shadow-lg"
            : "border-gray-200 hover:border-gray-300"
        }
      `}
      onClick={onClick}
      style={{ backgroundColor: slide.background || "#ffffff" }}
    >
      {renderContent()}

      {onEdit && (
        <button
          onClick={(e) => {
            e.stopPropagation();
            onEdit(slide);
          }}
          className="absolute top-2 right-2 p-2 bg-gray-100 hover:bg-gray-200 rounded-md opacity-0 group-hover:opacity-100 transition-opacity"
        >
          <svg
            className="w-4 h-4"
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"
            />
          </svg>
        </button>
      )}
    </div>
  );
};
