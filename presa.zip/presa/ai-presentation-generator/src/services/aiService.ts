import type {
  AIGenerationRequest,
  AIGenerationResponse,
  Slide,
  PresentationTemplate,
} from "../types/presentation";

// Моковые шаблоны презентаций
const templates: PresentationTemplate[] = [
  {
    id: "professional",
    name: "Профессиональный",
    colors: {
      primary: "#2563eb",
      secondary: "#64748b",
      background: "#ffffff",
      text: "#1f2937",
      accent: "#3b82f6",
    },
    fonts: {
      heading: "Inter",
      body: "Inter",
    },
    styles: {
      headingSize: "2rem",
      bodySize: "1rem",
      spacing: "1.5rem",
    },
  },
];

// Для демонстрации используем моковые данные вместо реального AI API
export class AIService {
  private static instance: AIService;

  public static getInstance(): AIService {
    if (!AIService.instance) {
      AIService.instance = new AIService();
    }
    return AIService.instance;
  }

  async generatePresentation(
    request: AIGenerationRequest
  ): Promise<AIGenerationResponse> {
    // Имитируем задержку API
    await new Promise((resolve) => setTimeout(resolve, 2000));

    try {
      const slides = this.generateMockSlides(request);

      return {
        presentation: {
          title: this.generateTitle(request.prompt),
          slides,
          template: templates[0],
        },
        success: true,
      };
    } catch (error) {
      return {
        presentation: {
          title: "",
          slides: [],
          template: templates[0],
        },
        success: false,
        error: "Ошибка генерации презентации",
      };
    }
  }

  private generateTitle(prompt: string): string {
    // Простая логика генерации заголовка на основе промпта
    const words = prompt.toLowerCase().split(" ");
    const keyWords = words.filter((word) => word.length > 3);

    if (keyWords.length > 0) {
      return keyWords
        .slice(0, 3)
        .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
        .join(" ");
    }

    return "Новая презентация";
  }

  private generateMockSlides(request: AIGenerationRequest): Slide[] {
    const { prompt, slideCount = 5, tone = "professional" } = request;

    const slides: Slide[] = [
      {
        id: "slide-1",
        title: this.generateTitle(prompt),
        content: `Презентация на тему: ${prompt}`,
        layout: "title",
      },
    ];

    // Генерируем контентные слайды
    for (let i = 2; i <= slideCount; i++) {
      slides.push({
        id: `slide-${i}`,
        title: this.generateSlideTitle(prompt, i, tone),
        content: this.generateSlideContent(prompt, i, tone),
        layout: this.getRandomLayout(),
      });
    }

    return slides;
  }

  private generateSlideTitle(
    prompt: string,
    slideNumber: number,
    tone: string
  ): string {
    const topics = this.extractTopics(prompt);
    const titles = {
      professional: [
        "Введение",
        "Ключевые концепции",
        "Анализ ситуации",
        "Решения и подходы",
        "Результаты и выводы",
        "Следующие шаги",
        "Заключение",
      ],
      casual: [
        "Давайте начнем",
        "Что это такое?",
        "Почему это важно?",
        "Как это работает?",
        "Что мы получаем?",
        "Что дальше?",
        "Подводим итоги",
      ],
      academic: [
        "Постановка проблемы",
        "Теоретические основы",
        "Методология исследования",
        "Результаты исследования",
        "Обсуждение результатов",
        "Практические применения",
        "Выводы и рекомендации",
      ],
      creative: [
        "Вдохновение",
        "Идея",
        "Воплощение",
        "Инновации",
        "Творческий процесс",
        "Результат",
        "Будущее творчества",
      ],
    };

    const titleSet = titles[tone as keyof typeof titles] || titles.professional;
    return (
      titleSet[Math.min(slideNumber - 1, titleSet.length - 1)] ||
      `Слайд ${slideNumber}`
    );
  }

  private generateSlideContent(
    prompt: string,
    slideNumber: number,
    tone: string
  ): string {
    const topics = this.extractTopics(prompt);

    const contentTemplates = {
      professional: [
        `Ключевые аспекты ${
          topics[0] || "темы"
        }:\n• Анализ текущей ситуации\n• Выявление возможностей\n• Разработка стратегии\n• Планирование реализации`,
        `Основные принципы:\n• Системный подход\n• Фокус на результат\n• Непрерывное улучшение\n• Клиентоориентированность`,
        `Преимущества решения:\n• Повышение эффективности\n• Снижение затрат\n• Улучшение качества\n• Масштабируемость`,
      ],
      casual: [
        `Простыми словами о ${
          topics[0] || "теме"
        }:\n\nЭто как когда вы... Только в данном случае мы работаем с более сложными процессами, но принцип тот же.`,
        `Почему это круто?\n\n• Экономит время\n• Делает жизнь проще\n• Помогает достичь целей\n• Приносит удовольствие`,
        `Вот что мы имеем:\n\nПредставьте себе мир, где все работает как часы. Именно к этому мы стремимся с помощью нашего подхода.`,
      ],
    };

    const templates =
      contentTemplates[tone as keyof typeof contentTemplates] ||
      contentTemplates.professional;
    return (
      templates[Math.min(slideNumber - 2, templates.length - 1)] ||
      `Содержимое слайда ${slideNumber}`
    );
  }

  private extractTopics(prompt: string): string[] {
    // Простое извлечение ключевых слов
    return prompt
      .toLowerCase()
      .split(/[.,!?;]/)
      .join(" ")
      .split(" ")
      .filter((word) => word.length > 4)
      .slice(0, 3);
  }

  private getRandomLayout(): Slide["layout"] {
    const layouts: Slide["layout"][] = [
      "content",
      "bullet-points",
      "two-column",
    ];
    return layouts[Math.floor(Math.random() * layouts.length)];
  }
}

// Для интеграции с реальным OpenAI API (закомментировано для демо)
/*
import OpenAI from 'openai';

export class OpenAIService {
  private openai: OpenAI;

  constructor(apiKey: string) {
    this.openai = new OpenAI({
      apiKey,
      dangerouslyAllowBrowser: true // Только для демо! В продакшене используйте сервер
    });
  }

  async generatePresentation(request: AIGenerationRequest): Promise<AIGenerationResponse> {
    try {
      const prompt = this.buildPrompt(request);
      
      const completion = await this.openai.chat.completions.create({
        model: "gpt-3.5-turbo",
        messages: [
          {
            role: "system",
            content: "Ты эксперт по созданию презентаций. Создавай структурированный и информативный контент."
          },
          {
            role: "user",
            content: prompt
          }
        ],
        temperature: 0.7,
      });

      const content = completion.choices[0]?.message?.content;
      if (!content) {
        throw new Error('Не удалось получить ответ от AI');
      }

      const presentation = this.parseAIResponse(content, request);
      
      return {
        presentation,
        success: true
      };
    } catch (error) {
      return {
        presentation: {
          title: '',
          slides: [],
          template: templates[0]
        },
        success: false,
        error: error instanceof Error ? error.message : 'Неизвестная ошибка'
      };
    }
  }

  private buildPrompt(request: AIGenerationRequest): string {
    return `
Создай презентацию на тему: "${request.prompt}"

Требования:
- Количество слайдов: ${request.slideCount || 5}
- Стиль: ${request.tone || 'professional'}
- Аудитория: ${request.audience || 'общая'}

Верни результат в формате JSON:
{
  "title": "Заголовок презентации",
  "slides": [
    {
      "title": "Заголовок слайда",
      "content": "Содержимое слайда",
      "layout": "content|bullet-points|two-column|title"
    }
  ]
}
    `;
  }

  private parseAIResponse(content: string, request: AIGenerationRequest) {
    // Парсинг ответа от AI и преобразование в нужный формат
    // Реализация зависит от формата ответа вашего AI сервиса
  }
}
*/
