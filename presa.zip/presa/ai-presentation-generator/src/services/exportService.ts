import html2canvas from "html2canvas";
import jsPDF from "jspdf";
import type { Presentation, Slide } from "../types/presentation";

export class ExportService {
  private static instance: ExportService;

  public static getInstance(): ExportService {
    if (!ExportService.instance) {
      ExportService.instance = new ExportService();
    }
    return ExportService.instance;
  }

  async exportToPDF(presentation: Presentation): Promise<void> {
    try {
      // Создаем PDF документ
      const pdf = new jsPDF({
        orientation: "landscape",
        unit: "px",
        format: [1920, 1080],
      });

      // Экспортируем каждый слайд
      for (let i = 0; i < presentation.slides.length; i++) {
        const slide = presentation.slides[i];

        if (i > 0) {
          pdf.addPage();
        }

        await this.addSlideToPDF(pdf, slide, i);
      }

      // Скачиваем PDF
      pdf.save(`${presentation.title}.pdf`);
    } catch (error) {
      console.error("Ошибка экспорта в PDF:", error);
      throw new Error("Не удалось экспортировать презентацию в PDF");
    }
  }

  private async addSlideToPDF(
    pdf: jsPDF,
    slide: Slide,
    pageIndex: number
  ): Promise<void> {
    // Создаем временный элемент для рендеринга слайда
    const slideElement = this.createSlideElement(slide);
    document.body.appendChild(slideElement);

    try {
      // Конвертируем в canvas
      const canvas = await html2canvas(slideElement, {
        width: 1920,
        height: 1080,
        scale: 1,
        backgroundColor: slide.background || "#ffffff",
      });

      // Добавляем изображение в PDF
      const imgData = canvas.toDataURL("image/png");
      pdf.addImage(imgData, "PNG", 0, 0, 1920, 1080);
    } finally {
      // Удаляем временный элемент
      document.body.removeChild(slideElement);
    }
  }

  private createSlideElement(slide: Slide): HTMLElement {
    const slideDiv = document.createElement("div");
    slideDiv.style.width = "1920px";
    slideDiv.style.height = "1080px";
    slideDiv.style.padding = "80px";
    slideDiv.style.backgroundColor = slide.background || "#ffffff";
    slideDiv.style.fontFamily = "Inter, sans-serif";
    slideDiv.style.position = "absolute";
    slideDiv.style.top = "-10000px"; // Скрываем за пределами экрана
    slideDiv.style.left = "-10000px";

    const content = this.renderSlideContent(slide);
    slideDiv.innerHTML = content;

    return slideDiv;
  }

  private renderSlideContent(slide: Slide): string {
    switch (slide.layout) {
      case "title":
        return `
          <div style="height: 100%; display: flex; flex-direction: column; justify-content: center; align-items: center; text-align: center;">
            <h1 style="font-size: 4rem; font-weight: bold; color: #1f2937; margin-bottom: 2rem; line-height: 1.2;">${slide.title}</h1>
            <p style="font-size: 2rem; color: #6b7280; line-height: 1.5;">${slide.content}</p>
          </div>
        `;

      case "content":
        return `
          <div style="height: 100%; display: flex; flex-direction: column;">
            <h2 style="font-size: 3rem; font-weight: bold; color: #1f2937; margin-bottom: 3rem;">${
              slide.title
            }</h2>
            <div style="flex: 1; font-size: 1.5rem; color: #374151; line-height: 1.8;">
              ${slide.content
                .split("\n")
                .map((line) => `<p style="margin-bottom: 2rem;">${line}</p>`)
                .join("")}
            </div>
          </div>
        `;

      case "bullet-points":
        const points = slide.content.split("\n").filter((line) => line.trim());
        return `
          <div style="height: 100%; display: flex; flex-direction: column;">
            <h2 style="font-size: 3rem; font-weight: bold; color: #1f2937; margin-bottom: 3rem;">${
              slide.title
            }</h2>
            <ul style="flex: 1; font-size: 1.5rem; color: #374151; line-height: 1.8;">
              ${points
                .map(
                  (point) => `
                <li style="display: flex; align-items: flex-start; margin-bottom: 1.5rem;">
                  <span style="width: 12px; height: 12px; background-color: #2563eb; border-radius: 50%; margin-top: 12px; margin-right: 2rem; flex-shrink: 0;"></span>
                  <span>${point.replace(/^[•\-*]\s*/, "")}</span>
                </li>
              `
                )
                .join("")}
            </ul>
          </div>
        `;

      case "two-column":
        const [leftContent, rightContent] = slide.content.split("---");
        return `
          <div style="height: 100%; display: flex; flex-direction: column;">
            <h2 style="font-size: 3rem; font-weight: bold; color: #1f2937; margin-bottom: 3rem;">${
              slide.title
            }</h2>
            <div style="flex: 1; display: grid; grid-template-columns: 1fr 1fr; gap: 4rem;">
              <div style="font-size: 1.5rem; color: #374151; line-height: 1.8;">
                ${(leftContent || "")
                  .split("\n")
                  .map((line) => `<p style="margin-bottom: 2rem;">${line}</p>`)
                  .join("")}
              </div>
              <div style="font-size: 1.5rem; color: #374151; line-height: 1.8;">
                ${(rightContent || "")
                  .split("\n")
                  .map((line) => `<p style="margin-bottom: 2rem;">${line}</p>`)
                  .join("")}
              </div>
            </div>
          </div>
        `;

      default:
        return `
          <div style="height: 100%; display: flex; flex-direction: column; justify-content: center; align-items: center;">
            <h2 style="font-size: 2.5rem; font-weight: bold; color: #1f2937; margin-bottom: 2rem;">${slide.title}</h2>
            <p style="font-size: 1.5rem; color: #6b7280;">${slide.content}</p>
          </div>
        `;
    }
  }

  async exportToImages(presentation: Presentation): Promise<string[]> {
    const images: string[] = [];

    for (const slide of presentation.slides) {
      const slideElement = this.createSlideElement(slide);
      document.body.appendChild(slideElement);

      try {
        const canvas = await html2canvas(slideElement, {
          width: 1920,
          height: 1080,
          scale: 1,
          backgroundColor: slide.background || "#ffffff",
        });

        images.push(canvas.toDataURL("image/png"));
      } finally {
        document.body.removeChild(slideElement);
      }
    }

    return images;
  }

  downloadAsJSON(presentation: Presentation): void {
    const dataStr = JSON.stringify(presentation, null, 2);
    const dataBlob = new Blob([dataStr], { type: "application/json" });

    const url = URL.createObjectURL(dataBlob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `${presentation.title}.json`;
    link.click();

    URL.revokeObjectURL(url);
  }
}
