export interface Slide {
  id: string;
  title: string;
  content: string;
  layout: "title" | "content" | "image" | "bullet-points" | "two-column";
  background?: string;
  template?: string;
}

export interface Presentation {
  id: string;
  title: string;
  slides: Slide[];
  template: PresentationTemplate;
  createdAt: Date;
  updatedAt: Date;
}

export interface PresentationTemplate {
  id: string;
  name: string;
  colors: {
    primary: string;
    secondary: string;
    background: string;
    text: string;
    accent: string;
  };
  fonts: {
    heading: string;
    body: string;
  };
  styles: {
    headingSize: string;
    bodySize: string;
    spacing: string;
  };
}

export interface AIGenerationRequest {
  prompt: string;
  slideCount?: number;
  template?: string;
  tone?: "professional" | "casual" | "academic" | "creative";
  audience?: string;
}

export interface AIGenerationResponse {
  presentation: Omit<Presentation, "id" | "createdAt" | "updatedAt">;
  success: boolean;
  error?: string;
}
