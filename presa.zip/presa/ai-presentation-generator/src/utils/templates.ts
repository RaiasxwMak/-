import type { PresentationTemplate } from "../types/presentation";

export const presentationTemplates: PresentationTemplate[] = [
  {
    id: "professional",
    name: "Профессиональный",
    colors: {
      primary: "#2563eb",
      secondary: "#64748b",
      background: "#ffffff",
      text: "#1f2937",
      accent: "#3b82f6",
    },
    fonts: {
      heading: "Inter",
      body: "Inter",
    },
    styles: {
      headingSize: "2.5rem",
      bodySize: "1.125rem",
      spacing: "1.5rem",
    },
  },
  {
    id: "modern",
    name: "Современный",
    colors: {
      primary: "#7c3aed",
      secondary: "#6b7280",
      background: "#f8fafc",
      text: "#111827",
      accent: "#8b5cf6",
    },
    fonts: {
      heading: "Inter",
      body: "Inter",
    },
    styles: {
      headingSize: "2.5rem",
      bodySize: "1.125rem",
      spacing: "1.75rem",
    },
  },
  {
    id: "creative",
    name: "Креативный",
    colors: {
      primary: "#ec4899",
      secondary: "#64748b",
      background: "#fefce8",
      text: "#18181b",
      accent: "#f59e0b",
    },
    fonts: {
      heading: "Inter",
      body: "Inter",
    },
    styles: {
      headingSize: "3rem",
      bodySize: "1.125rem",
      spacing: "2rem",
    },
  },
  {
    id: "corporate",
    name: "Корпоративный",
    colors: {
      primary: "#1f2937",
      secondary: "#6b7280",
      background: "#ffffff",
      text: "#374151",
      accent: "#059669",
    },
    fonts: {
      heading: "Inter",
      body: "Inter",
    },
    styles: {
      headingSize: "2.25rem",
      bodySize: "1rem",
      spacing: "1.25rem",
    },
  },
  {
    id: "academic",
    name: "Академический",
    colors: {
      primary: "#1e40af",
      secondary: "#6b7280",
      background: "#ffffff",
      text: "#1f2937",
      accent: "#dc2626",
    },
    fonts: {
      heading: "Inter",
      body: "Inter",
    },
    styles: {
      headingSize: "2rem",
      bodySize: "1rem",
      spacing: "1.5rem",
    },
  },
  {
    id: "minimal",
    name: "Минималистичный",
    colors: {
      primary: "#000000",
      secondary: "#6b7280",
      background: "#ffffff",
      text: "#111827",
      accent: "#374151",
    },
    fonts: {
      heading: "Inter",
      body: "Inter",
    },
    styles: {
      headingSize: "2.25rem",
      bodySize: "1.125rem",
      spacing: "2rem",
    },
  },
];

export const getTemplateById = (id: string): PresentationTemplate => {
  return (
    presentationTemplates.find((template) => template.id === id) ||
    presentationTemplates[0]
  );
};

export const getRandomTemplate = (): PresentationTemplate => {
  const randomIndex = Math.floor(Math.random() * presentationTemplates.length);
  return presentationTemplates[randomIndex];
};
